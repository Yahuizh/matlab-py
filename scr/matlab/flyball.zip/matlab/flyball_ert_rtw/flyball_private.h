#ifndef flyball_private_h_
#define flyball_private_h_
#include "rtwtypes.h"
#include "flyball_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"

extern void flyball_derivatives();

#endif

